import React from "react";
import Person from "./Pages/Person/Person";

const Contact = () => {
  return (
    <div>
      <h1>Contact Components</h1>
      {/* {<p>{newPerson.name} is a ful stack Developer</p>} */}
    </div>
  );
};

export default Contact;
