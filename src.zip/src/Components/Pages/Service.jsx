import React from "react";

const Service = () => {
  return (
    <div>
      <h1>Service Page</h1>
    </div>
  );
};

export default Service;
