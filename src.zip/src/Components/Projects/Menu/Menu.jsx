import React from "react";
import { BiSolidChevronLeft, BiSolidChevronRight } from "react-icons/bi";
import "./Menu.css";

function Menu() {
  return (
    <div>
      <div className="menu_container">
        <div className="h3">
          <h3>Our Menu</h3>
          <div className="menu_ball"></div>
          <div className="menu_ball2"></div>
        </div>
        <div className="div_2">
          <h2>Menu that ALways</h2>
          <div className="div_3">
            <h2> Make you fall in love</h2>

            <div className="btn2">
              <button>
                <BiSolidChevronLeft fontSize={30} />
              </button>
              <button>
                <BiSolidChevronRight color="white" fontSize={30} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Menu;
